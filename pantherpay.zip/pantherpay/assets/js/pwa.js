'use strict';
(function(){
  let deferredPrompt = null;
  const banner = document.getElementById('pwa-install-banner');
  const action = document.getElementById('pwa-install-action');
  const dismiss = document.getElementById('pwa-install-dismiss');
  let autoHideTimer = null;

  function isStandalone(){
    return window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
  }

  function showBanner(){ if (banner) banner.classList.remove('hidden'); }
  function hideBanner(){ if (banner) banner.classList.add('hidden'); }

  // Cache prompt event when available (Chrome/Edge)
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
  });

  // Login-triggered banner: after successful login we redirect with ?li=1
  // Show after 10s, and auto-hide after 30s of visibility
  document.addEventListener('DOMContentLoaded', () => {
    if (isStandalone()) return; // already installed
    const params = new URLSearchParams(location.search);
    const fromLogin = params.get('li') === '1';
    if (!fromLogin) return; // only trigger after login
    setTimeout(() => {
      if (!isStandalone()) {
        showBanner();
        if (autoHideTimer) clearTimeout(autoHideTimer);
        autoHideTimer = setTimeout(() => hideBanner(), 30000);
      }
    }, 10000);
  });

  if (dismiss) dismiss.addEventListener('click', () => hideBanner());

  if (action) action.addEventListener('click', async () => {
    // iOS fallback: manual instruction
    const isIOS = /iphone|ipad|ipod/i.test(window.navigator.userAgent);
    if (isIOS && !('BeforeInstallPromptEvent' in window)) {
      alert('To install: tap the Share icon, then "Add to Home Screen".');
      hideBanner();
      return;
    }
    if (!deferredPrompt) {
      // Prompt not captured yet; try shortly again
      setTimeout(() => action.click(), 800);
      return;
    }
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    deferredPrompt = null;
    if (outcome === 'accepted') hideBanner();
  });

  // Hide banner when app enters standalone
  window.matchMedia('(display-mode: standalone)').addEventListener('change', (ev) => {
    if (ev.matches) hideBanner();
  });

  // Register Service Worker
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js', { scope: '/' }).catch(()=>{});
    });
  }
})();
