// Dark mode toggle (respects forced dark mode per page)
(function(){
  const key = 'pp.dark';
  const btn = document.querySelector('[data-toggle-dark]');
  const root = document.body;
  const forced = root.getAttribute('data-force-dark') === '1';
  function apply(){
    if(forced){
      root.classList.add('dark');
      return;
    }
    if(localStorage.getItem(key)==='1') root.classList.add('dark'); else root.classList.remove('dark');
  }
  if(btn && !forced){
    btn.addEventListener('click', ()=>{ const v = localStorage.getItem(key)==='1' ? '0':'1'; localStorage.setItem(key, v); apply(); });
  }
  apply();
})();

// In-page notices (success = green, error = red)
(function(){
  function ensureContainer(){
    let wrap = document.querySelector('[data-notice-wrap]');
    if(!wrap){
      wrap = document.createElement('div');
      wrap.setAttribute('data-notice-wrap','');
      wrap.className = 'max-w-5xl mx-auto px-4 pt-4';
      const main = document.querySelector('main') || document.body;
      main.insertBefore(wrap, main.firstChild);
    }
    return wrap;
  }
  window.showNotice = function(message, type){
    const wrap = ensureContainer();
    const div = document.createElement('div');
    const cls = type==='success' ? 'success' : (type==='error' ? 'error' : 'info');
    div.className = `notice ${cls}`;
    div.innerHTML = `<span>${message}</span><button class="close" aria-label="Close">&times;</button>`;
    wrap.appendChild(div);
    // Auto dismiss after 5s
    setTimeout(()=>{ if(div && div.parentNode) div.parentNode.removeChild(div); }, 5000);
  };
  // Dismiss on click for any server-rendered or client notices
  document.addEventListener('click', (e)=>{
    const btn = e.target.closest('.notice .close');
    if(btn){
      const box = btn.closest('.notice');
      if(box) box.remove();
    }
  });
})();

// Admin: AJAX approve/reject actions
(function(){
  function getCsrf(){
    const el = document.querySelector('input[name="_csrf"]');
    return el ? el.value : '';
  }
  function closestRow(el){
    return el.closest('tr');
  }
  async function post(url, data){
    const body = new URLSearchParams(data || {});
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'CSRF-Token': getCsrf()
      },
      body: body.toString(),
      redirect: 'follow'
    });
    return res;
  }
  document.addEventListener('click', async (e)=>{
    const btn = e.target.closest('[data-ajax-url]');
    if(!btn) return;
    e.preventDefault();
    if(btn.disabled) return;
    const url = btn.getAttribute('data-ajax-url');
    const status = btn.getAttribute('data-status');
    btn.disabled = true;
    try{
      const res = await post(url, Object.assign({ _csrf: getCsrf() }, status ? { status } : {}));
      if(res.ok){
        const tr = closestRow(btn);
        if(tr){
          // Mark as updated; if there is a badge cell, update; else, fade out
          tr.style.opacity = '0.5';
        }
        showNotice('Action completed successfully', 'success');
      } else {
        showNotice('Action failed', 'error');
        btn.disabled = false;
      }
    }catch(err){
      console.error(err);
      showNotice('Network error', 'error');
      btn.disabled = false;
    }
  });
})();

// Step toggles (Top-Up 4-step layout)
(function(){
  document.addEventListener('click', (e)=>{
    const toggle = e.target.closest('[data-step-toggle]');
    if(!toggle) return;
    const id = toggle.getAttribute('data-step-toggle');
    // Collapse other lists
    document.querySelectorAll('[data-step-list]').forEach(list=>{
      if(list.getAttribute('data-step-list') === id){
        list.classList.toggle('hidden');
      } else {
        list.classList.add('hidden');
      }
    });
  });
})();

// Real-time total update for topup (supports multiple grids)
(function(){
  const grids = document.querySelectorAll('[data-grid-packs]');
  const totalEl = document.querySelector('[data-total]');
  const inputId = document.querySelector('input[name="product_id"]');
  if(!grids.length || !totalEl || !inputId) return;
  grids.forEach(container=>{
    container.querySelectorAll('button[data-id]').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        // Remove active from all buttons across all grids
        document.querySelectorAll('[data-grid-packs] button').forEach(b=>b.classList.remove('active'));
        btn.classList.add('active');
        // dataset.price is already final (converted) value in the view
        const finalPrice = parseFloat(btn.dataset.price);
        const value = isNaN(finalPrice) ? 0 : finalPrice;
        totalEl.textContent = value.toFixed(2);
        inputId.value = btn.dataset.id;
      });
    });
  });
})();

// Prevent submit if required selections are missing on Top-up form
(function(){
  const form = document.querySelector('form[action="/user/topup"]');
  if(!form) return;
  form.addEventListener('submit', (e)=>{
    const pid = form.querySelector('input[name="product_id"]').value.trim();
    const uid = form.querySelector('input[name="game_uid"]').value.trim();
    const totalEl = document.querySelector('[data-total]');
    const total = parseFloat(totalEl ? totalEl.textContent : '0') || 0;
    const balance = parseFloat(document.body.getAttribute('data-user-balance') || '0') || 0;
    const errs = [];
    if(!pid) errs.push('Please select a diamond package.');
    if(!uid) errs.push('Please enter your Game UID.');
    if(errs.length){
      e.preventDefault();
      showNotice(errs.join('\n'), 'error');
      return;
    }
    // Balance check logic
    if(total <= balance){
      // Enough balance: show confirmation and submit after short delay
      e.preventDefault();
      showNotice('Top-Up Request Confirmed', 'success');
      setTimeout(()=>{ form.submit(); }, 800);
    } else {
      // Not enough balance: stop and inform user
      e.preventDefault();
      showNotice('Insufficient Balance, please Add Money', 'error');
    }
  });
})();

// Client-side validation hints
(function(){
  document.querySelectorAll('form[data-validate] input[required]').forEach(inp=>{
    inp.addEventListener('invalid', ()=>{
      const msg = inp.dataset.msg || 'Invalid input';
      let hint = inp.parentElement.querySelector('.input-error');
      if(!hint){ hint = document.createElement('div'); hint.className='input-error'; inp.parentElement.appendChild(hint); }
      hint.textContent = msg;
    });
    inp.addEventListener('input', ()=>{
      let hint = inp.parentElement.querySelector('.input-error');
      if(hint) hint.remove();
    });
  });
})();

// Search filter for admin tables
(function(){
  const search = document.querySelector('[data-admin-search]');
  const rows = document.querySelectorAll('[data-admin-table] tbody tr');
  if(!search || !rows.length) return;
  search.addEventListener('input', ()=>{
    const q = search.value.toLowerCase();
    rows.forEach(r=>{
      r.style.display = r.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
  });
})();

// Simple modal toggles (for account edit)
(function(){
  const openers = document.querySelectorAll('[data-open-modal]');
  const body = document.body;
  function open(id){
    const modal = document.querySelector(`[data-modal="${id}"]`);
    if(!modal) return;
    modal.classList.remove('hidden');
    body.style.overflow = 'hidden';
  }
  function close(modal){
    modal.classList.add('hidden');
    body.style.overflow = '';
  }
  openers.forEach(btn=>{
    btn.addEventListener('click', ()=> open(btn.getAttribute('data-open-modal')));
  });
  document.querySelectorAll('[data-modal]').forEach(modal=>{
    modal.addEventListener('click', (e)=>{
      if(e.target.hasAttribute('data-close-modal') || e.target.getAttribute('data-close-modal') === '' || e.target.closest('[data-close-modal]')){
        close(modal);
      }
    });
    // Also close on ESC
    document.addEventListener('keydown', (e)=>{
      if(e.key === 'Escape' && !modal.classList.contains('hidden')) close(modal);
    });
  });
})();
