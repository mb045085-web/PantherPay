const path = require('path');
const fs = require('fs');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');

const dataDir = path.join(__dirname, '../../data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const dbPath = path.join(dataDir, 'pantherpay.sqlite');
const db = new sqlite3.Database(dbPath);

function runAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) reject(err); else resolve(this);
    });
  });
}

function getAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, function (err, row) {
      if (err) reject(err); else resolve(row);
    });
  });
}

function allAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, function (err, rows) {
      if (err) reject(err); else resolve(rows);
    });
  });
}

async function initDb() {
  await runAsync(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    email TEXT UNIQUE,
    password_hash TEXT,
    balance REAL DEFAULT 0,
    role TEXT DEFAULT 'user',
    google_id TEXT,
    phone TEXT,
    avatar_url TEXT
  )`);

  await runAsync(`CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    diamond_qty INTEGER,
    price REAL,
    enabled INTEGER DEFAULT 1,
    kind TEXT DEFAULT 'pack', -- pack | weekly | monthly | levelup | pass | weekly_lite
    plan_name TEXT
  )`);

  await runAsync(`CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    diamond_qty INTEGER,
    price REAL,
    status TEXT DEFAULT 'pending',
    payment_method TEXT DEFAULT 'wallet',
    game_uid TEXT,
    wallet_deducted REAL DEFAULT 0,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
  )`);

  await runAsync(`CREATE TABLE IF NOT EXISTS admin_settings (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    logo_url TEXT,
    header_image_url TEXT,
    currency_symbol TEXT DEFAULT '৳',
    currency_rate REAL DEFAULT 1.0,
    step1_title TEXT,
    step1_image TEXT,
    step2_title TEXT,
    step2_image TEXT,
    step3_title TEXT,
    step3_image TEXT,
    step4_title TEXT,
    step4_image TEXT
  )`);

  // Extra tables for extended admin modules
  await runAsync(`CREATE TABLE IF NOT EXISTS notices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    content TEXT,
    level TEXT DEFAULT 'info', -- info | warning | danger
    active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  await runAsync(`CREATE TABLE IF NOT EXISTS banners (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    image_url TEXT,
    link_url TEXT,
    active INTEGER DEFAULT 1,
    sort_order INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  await runAsync(`CREATE TABLE IF NOT EXISTS offers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    image_url TEXT,
    price REAL,
    active INTEGER DEFAULT 1,
    kind TEXT DEFAULT 'deal', -- deal | uid
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  await runAsync(`CREATE TABLE IF NOT EXISTS payment_settings (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    wallet_enabled INTEGER DEFAULT 1,
    bkash_enabled INTEGER DEFAULT 0,
    nagad_enabled INTEGER DEFAULT 0,
    rocket_enabled INTEGER DEFAULT 0,
    bkash_key TEXT,
    nagad_key TEXT,
    rocket_key TEXT,
    bkash_number TEXT,
    nagad_number TEXT,
    rocket_number TEXT
  )`);

  await runAsync(`CREATE TABLE IF NOT EXISTS promo_codes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT UNIQUE,
    discount_percent INTEGER DEFAULT 0,
    max_uses INTEGER DEFAULT 0,
    used_count INTEGER DEFAULT 0,
    expires_at DATETIME,
    active INTEGER DEFAULT 1
  )`);

  await runAsync(`CREATE TABLE IF NOT EXISTS wallet_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    type TEXT, -- deposit | withdraw
    amount REAL,
    method TEXT, -- wallet | bkash | nagad | rocket
    txn_id TEXT,
    status TEXT DEFAULT 'pending', -- pending | approved | rejected
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
  )`);

  await runAsync(`CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    message TEXT,
    read INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
  )`);

  // Seed settings
  const settings = await getAsync('SELECT * FROM admin_settings WHERE id = 1');
  if (!settings) {
    await runAsync('INSERT INTO admin_settings (id, logo_url, header_image_url, currency_symbol, currency_rate, step1_title, step1_image, step2_title, step2_image, step3_title, step3_image, step4_title, step4_image) VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [
      process.env.DEFAULT_LOGO_URL || 'https://short-url.org/1buGt',
      process.env.DEFAULT_HEADER_IMAGE_URL || 'https://images.unsplash.com/photo-1511512578047-dfb367046420?q=80&w=1600&auto=format&fit=crop',
      process.env.DEFAULT_CURRENCY_SYMBOL || '৳',
      Number(process.env.DEFAULT_CURRENCY_RATE || 1),
      'Free Fire TopUp', 'https://short-url.org/1gcBY',
      'Level Up Pass', 'https://short-url.org/1gcD0',
      'Weekly & Monthly', 'https://short-url.org/1gcDf',
      'Weekly Lite', 'https://short-url.org/1gcDw'
    ]);
  }

  const pay = await getAsync('SELECT * FROM payment_settings WHERE id = 1');
  if (!pay) {
    await runAsync('INSERT INTO payment_settings (id) VALUES (1)');
  }

  // Seed admin user
  const admin = await getAsync("SELECT * FROM users WHERE email = 'admin@pantherpay.local'");
  if (!admin) {
    const hash = await bcrypt.hash('admin123', 10);
    await runAsync('INSERT INTO users (name, email, password_hash, role, balance) VALUES (?, ?, ?, ?, ?)', [
      'Administrator', 'admin@pantherpay.local', hash, 'admin', 0
    ]);
  }

  // Seed sample products
  const prodCount = await getAsync('SELECT COUNT(*) as cnt FROM products');
  if (!prodCount || prodCount.cnt === 0) {
    const packs = [
      { q: 100, p: 1.0 },
      { q: 310, p: 3.0 },
      { q: 520, p: 5.0 },
      { q: 1060, p: 10.0 }
    ];
    for (const pack of packs) {
      await runAsync('INSERT INTO products (diamond_qty, price, enabled, kind) VALUES (?, ?, 1, "pack")', [pack.q, pack.p]);
    }
  }

  // Try to ALTER TABLE for backward compatibility if upgrading
  const safeAlter = async (sql) => { try { await runAsync(sql); } catch (e) { /* ignore */ } };
  await safeAlter('ALTER TABLE products ADD COLUMN enabled INTEGER DEFAULT 1');
  await safeAlter('ALTER TABLE products ADD COLUMN kind TEXT DEFAULT "pack"');
  await safeAlter('ALTER TABLE products ADD COLUMN plan_name TEXT');
  await safeAlter('ALTER TABLE transactions ADD COLUMN payment_method TEXT DEFAULT "wallet"');
  await safeAlter('ALTER TABLE transactions ADD COLUMN game_uid TEXT');
  await safeAlter('ALTER TABLE transactions ADD COLUMN wallet_deducted REAL DEFAULT 0');
  await safeAlter('ALTER TABLE users ADD COLUMN phone TEXT');
  await safeAlter('ALTER TABLE users ADD COLUMN avatar_url TEXT');
  await safeAlter('ALTER TABLE users ADD COLUMN last_login DATETIME');
  await safeAlter('CREATE TABLE IF NOT EXISTS wallet_transactions (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, type TEXT, amount REAL, method TEXT, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id))');
  await safeAlter('ALTER TABLE wallet_transactions ADD COLUMN txn_id TEXT');
  await safeAlter('ALTER TABLE wallet_transactions ADD COLUMN status TEXT DEFAULT "pending"');
  await safeAlter('ALTER TABLE payment_settings ADD COLUMN bkash_number TEXT');
  await safeAlter('ALTER TABLE payment_settings ADD COLUMN nagad_number TEXT');
  await safeAlter('ALTER TABLE payment_settings ADD COLUMN rocket_number TEXT');
  await safeAlter('ALTER TABLE admin_settings ADD COLUMN currency_symbol TEXT DEFAULT "৳"');
  await safeAlter('ALTER TABLE admin_settings ADD COLUMN currency_rate REAL DEFAULT 1.0');
  await safeAlter('ALTER TABLE admin_settings ADD COLUMN step1_title TEXT');
  await safeAlter('ALTER TABLE admin_settings ADD COLUMN step1_image TEXT');
  await safeAlter('ALTER TABLE admin_settings ADD COLUMN step2_title TEXT');
  await safeAlter('ALTER TABLE admin_settings ADD COLUMN step2_image TEXT');
  await safeAlter('ALTER TABLE admin_settings ADD COLUMN step3_title TEXT');
  await safeAlter('ALTER TABLE admin_settings ADD COLUMN step3_image TEXT');
  await safeAlter('ALTER TABLE admin_settings ADD COLUMN step4_title TEXT');
  await safeAlter('ALTER TABLE admin_settings ADD COLUMN step4_image TEXT');
  await safeAlter('CREATE TABLE IF NOT EXISTS notifications (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, message TEXT, read INTEGER DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id))');
}

async function getSettings() {
  const row = await getAsync('SELECT * FROM admin_settings WHERE id = 1');
  return row || {
    logo_url: process.env.DEFAULT_LOGO_URL,
    header_image_url: process.env.DEFAULT_HEADER_IMAGE_URL,
    currency_symbol: (process.env.DEFAULT_CURRENCY_SYMBOL || '৳'),
    currency_rate: Number(process.env.DEFAULT_CURRENCY_RATE || 1),
    step1_title: 'Free Fire TopUp',
    step1_image: 'https://short-url.org/1gcBY',
    step2_title: 'Level Up Pass',
    step2_image: 'https://short-url.org/1gcD0',
    step3_title: 'Weekly & Monthly',
    step3_image: 'https://short-url.org/1gcDf',
    step4_title: 'Weekly Lite',
    step4_image: 'https://short-url.org/1gcDw'
  };
}

module.exports = {
  db, runAsync, getAsync, allAsync, initDb, getSettings
};
