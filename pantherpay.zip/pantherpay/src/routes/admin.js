const express = require('express');
const { ensureAdmin } = require('../middleware/auth');
const { allAsync, getAsync, runAsync } = require('../db/db');
const { body, validationResult } = require('express-validator');

const router = express.Router();

router.get('/dashboard', ensureAdmin, async (req, res) => {
  // Minimal dashboard with three navigation buttons
  const stats = {
    users: (await getAsync('SELECT COUNT(*) as c FROM users')).c,
    transactions: (await getAsync('SELECT COUNT(*) as c FROM transactions')).c
  };
  // Seed baseline: mark current pending as seen so badges start at 0 and only rise on new arrivals
  try {
    await runAsync("INSERT OR IGNORE INTO admin_seen(type, item_id) SELECT 'deposit', id FROM wallet_transactions WHERE type='deposit' AND status='pending'");
    await runAsync("INSERT OR IGNORE INTO admin_seen(type, item_id) SELECT 'topup', id FROM transactions WHERE status='pending'");
  } catch(_) {}
  res.render('admin/dashboard', { title: 'Admin Dashboard', stats });
});

// Users management
router.get('/users', ensureAdmin, async (req, res) => {
  const q = (req.query.q || '').trim();
  const base = 'SELECT u.*, (SELECT COUNT(1) FROM transactions t WHERE t.user_id = u.id) as topup_count FROM users u';
  const users = q
    ? await allAsync(base + ' WHERE u.email LIKE ? OR u.name LIKE ? ORDER BY u.id DESC', [`%${q}%`, `%${q}%`])
    : await allAsync(base + ' ORDER BY u.id DESC');
  res.render('admin/users', { title: 'Manage Users', users, q });
});

router.post('/users/:id/balance', ensureAdmin,
  body('amount').isFloat().withMessage('Amount required'),
  async (req, res) => {
    const { id } = req.params; const amount = parseFloat(req.body.amount);
    await runAsync('UPDATE users SET balance = ROUND(balance + ?, 2) WHERE id = ?', [amount, id]);
    req.flash('success', 'Balance updated');
    res.redirect('/admin/users');
  }
);

router.post('/users/:id/role', ensureAdmin, async (req, res) => {
  await runAsync('UPDATE users SET role = ? WHERE id = ?', [role, id]);
  req.flash('success', 'Role updated');
  res.redirect('/admin/users' + (req.query.section ? ('?section=' + encodeURIComponent(req.query.section)) : ''));
});

  // Products management
router.get('/products', ensureAdmin, async (req, res) => {
  const section = (req.query.section || '').toLowerCase();
  let sql = 'SELECT * FROM products WHERE 1=1';
  if (section === 'levelup') {
    sql += " AND LOWER(kind) IN ('levelup','pass')";
  } else if (section === 'weekly') {
    sql += " AND LOWER(kind) = 'weekly'";
  } else if (section === 'monthly') {
    sql += " AND LOWER(kind) = 'monthly'";
  } else if (section === 'weekly-lite') {
    sql += " AND (LOWER(kind) LIKE 'weekly%lite%' OR LOWER(kind) = 'weekly_lite' OR LOWER(kind) = 'weekly lite')";
  } else if (section === 'freefire') {
    sql += " AND (kind IS NULL OR TRIM(kind) = '' OR LOWER(kind) NOT IN ('weekly','monthly','pass','levelup','weekly_lite','weekly lite'))";
  } else if (section === 'weekly-monthly') {
    // Backward-compatible alias shows both
    sql += " AND LOWER(kind) IN ('weekly','monthly')";
  }
  sql += ' ORDER BY enabled DESC, price ASC';
  const products = await allAsync(sql);
  res.render('admin/products', { title: 'Manage Products', products, section });
});

router.post('/products', ensureAdmin,
  body('diamond_qty').isInt({ min: 1 }).withMessage('Diamond qty required'),
  body('price').isFloat({ min: 0 }).withMessage('Price required'),
  body('kind').optional().isString(),
  body('enabled').optional().isIn(['0','1']),
  body('plan_name').optional().isString(),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      req.flash('error', errors.array().map(e => e.msg).join(', '));
      return res.redirect('/admin/products' + (req.query.section ? ('?section=' + encodeURIComponent(req.query.section)) : ''));
    }
    const kind = (req.body.kind || 'pack').toLowerCase();
    const enabled = req.body.enabled === '0' ? 0 : 1;
    const planName = req.body.plan_name || null;
    await runAsync('INSERT INTO products (diamond_qty, price, kind, enabled, plan_name) VALUES (?, ?, ?, ?, ?)', [req.body.diamond_qty, req.body.price, kind, enabled, planName]);
    req.flash('success', 'Product added');
    res.redirect('/admin/products' + (req.query.section ? ('?section=' + encodeURIComponent(req.query.section)) : ''));
  }
);

router.post('/products/:id', ensureAdmin,
  body('diamond_qty').isInt({ min: 1 }),
  body('price').isFloat({ min: 0 }),
  body('kind').optional().isString(),
  body('enabled').optional().isIn(['0','1']),
  body('plan_name').optional().isString(),
  async (req, res) => {
    const kind = (req.body.kind || 'pack').toLowerCase();
    const enabled = req.body.enabled === '0' ? 0 : 1;
    const planName = req.body.plan_name || null;
    await runAsync('UPDATE products SET diamond_qty=?, price=?, kind=?, enabled=?, plan_name=? WHERE id=?', [req.body.diamond_qty, req.body.price, kind, enabled, planName, req.params.id]);
    req.flash('success', 'Product updated');
    res.redirect('/admin/products' + (req.query.section ? ('?section=' + encodeURIComponent(req.query.section)) : ''));
  }
);

router.post('/products/:id/delete', ensureAdmin, async (req, res) => {
  await runAsync('DELETE FROM products WHERE id=?', [req.params.id]);
  req.flash('success', 'Product deleted');
  res.redirect('/admin/products');
});

// Alias route for Packages management
router.get('/packages', ensureAdmin, async (req, res) => {
  const products = await allAsync('SELECT * FROM products ORDER BY price ASC');
  res.render('admin/products', { title: 'Packages', products });
});

// Currency settings dedicated page
router.get('/currency', ensureAdmin, async (req, res) => {
  const settings = await getAsync('SELECT currency_symbol, currency_rate FROM admin_settings WHERE id=1');
  res.render('admin/currency', { title: 'Currency Settings', settings });
});

router.post('/currency', ensureAdmin,
  body('currency_symbol').notEmpty().isString().withMessage('Currency symbol required'),
  body('currency_rate').isFloat({ min: 0.0001 }).withMessage('Currency rate must be > 0'),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      req.flash('error', errors.array().map(e => e.msg).join(', '));
      return res.redirect('/admin/currency');
    }
    await runAsync('UPDATE admin_settings SET currency_symbol=?, currency_rate=? WHERE id=1', [req.body.currency_symbol, req.body.currency_rate]);
    req.flash('success', 'Currency updated');
    res.redirect('/admin/currency');
  }
);

// Branding (logo/header) dedicated page
router.get('/branding', ensureAdmin, async (req, res) => {
  const settings = await getAsync('SELECT logo_url, header_image_url FROM admin_settings WHERE id=1');
  res.render('admin/branding', { title: 'Branding', settings });
});

router.post('/branding', ensureAdmin,
  body('logo_url').isURL().withMessage('Valid logo URL required'),
  body('header_image_url').isURL().withMessage('Valid header URL required'),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      req.flash('error', errors.array().map(e => e.msg).join(', '));
      return res.redirect('/admin/branding');
    }
    await runAsync('UPDATE admin_settings SET logo_url=?, header_image_url=? WHERE id=1', [req.body.logo_url, req.body.header_image_url]);
    req.flash('success', 'Branding updated');
    res.redirect('/admin/branding');
  }
);

// Settings
router.get('/settings', ensureAdmin, async (req, res) => {
  const settings = await getAsync('SELECT * FROM admin_settings WHERE id=1');
  const pay = await getAsync('SELECT * FROM payment_settings WHERE id=1');
  res.render('admin/settings', { title: 'Settings', settings, pay });
});

router.post('/settings', ensureAdmin,
  body('logo_url').isURL().withMessage('Valid logo URL required'),
  body('header_image_url').isURL().withMessage('Valid header URL required'),
  body('currency_symbol').optional().isString(),
  body('currency_rate').optional().isFloat({ min: 0.0001 }),
  body('bkash_number').optional().isString(),
  body('nagad_number').optional().isString(),
  body('step1_title').optional().isString(),
  body('step1_image').optional().isString(),
  body('step2_title').optional().isString(),
  body('step2_image').optional().isString(),
  body('step3_title').optional().isString(),
  body('step3_image').optional().isString(),
  body('step4_title').optional().isString(),
  body('step4_image').optional().isString(),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      req.flash('error', errors.array().map(e => e.msg).join(', '));
      return res.redirect('/admin/settings');
    }
    await runAsync('UPDATE admin_settings SET logo_url=?, header_image_url=?, currency_symbol=COALESCE(?, currency_symbol), currency_rate=COALESCE(?, currency_rate), step1_title=COALESCE(?, step1_title), step1_image=COALESCE(?, step1_image), step2_title=COALESCE(?, step2_title), step2_image=COALESCE(?, step2_image), step3_title=COALESCE(?, step3_title), step3_image=COALESCE(?, step3_image), step4_title=COALESCE(?, step4_title), step4_image=COALESCE(?, step4_image) WHERE id=1', [
      req.body.logo_url, req.body.header_image_url, req.body.currency_symbol || null, req.body.currency_rate || null,
      req.body.step1_title || null, req.body.step1_image || null,
      req.body.step2_title || null, req.body.step2_image || null,
      req.body.step3_title || null, req.body.step3_image || null,
      req.body.step4_title || null, req.body.step4_image || null
    ]);
    await runAsync('UPDATE payment_settings SET bkash_number=COALESCE(?, bkash_number), nagad_number=COALESCE(?, nagad_number) WHERE id=1', [
      req.body.bkash_number || null, req.body.nagad_number || null
    ]);
    req.flash('success', 'Settings updated');
    res.redirect('/admin/settings');
  }
);

// Transactions moderation
router.get('/transactions', ensureAdmin, async (req, res) => {
  const q = (req.query.q || '').trim();
  const base = 'SELECT t.*, u.email FROM transactions t JOIN users u ON u.id = t.user_id';
  const transactions = q
    ? await allAsync(`${base} WHERE u.email LIKE ? OR t.status LIKE ? ORDER BY t.timestamp DESC`, [`%${q}%`, `%${q}%`])
    : await allAsync(base + ' ORDER BY t.timestamp DESC');
  res.render('admin/transactions', { title: 'Transactions', transactions, q });
});

router.post('/transactions/:id/status', ensureAdmin, async (req, res) => {
  const { id } = req.params; const newStatus = ['approved', 'rejected', 'pending'].includes(req.body.status) ? req.body.status : 'pending';
  const tx = await getAsync('SELECT * FROM transactions WHERE id = ?', [id]);
  if (!tx) { req.flash('error', 'Transaction not found'); return res.redirect('/admin/transactions'); }
  const prevStatus = tx.status;
  await runAsync('UPDATE transactions SET status=? WHERE id=?', [newStatus, id]);
  if (newStatus === 'rejected' && prevStatus !== 'rejected') {
    const refund = Number(tx.wallet_deducted || 0);
    if (refund > 0) {
      await runAsync('UPDATE users SET balance = balance + ? WHERE id = ?', [refund, tx.user_id]);
    }
    // Notify user
    await runAsync('INSERT INTO notifications (user_id, message) VALUES (?, ?)', [tx.user_id, 'Your top-up was rejected and any deducted amount has been refunded.']);
    // Keep only latest 3 notifications per user
    await runAsync('DELETE FROM notifications WHERE user_id = ? AND id NOT IN (SELECT id FROM notifications WHERE user_id = ? ORDER BY created_at DESC, id DESC LIMIT 3)', [tx.user_id, tx.user_id]);
    req.flash('success', refund > 0 ? `Top-up rejected. Refunded ${refund.toFixed(2)} to user wallet.` : 'Top-up rejected');
    return res.redirect('/admin/transactions');
  }
  if (newStatus === 'approved' && prevStatus !== 'approved') {
    await runAsync('INSERT INTO notifications (user_id, message) VALUES (?, ?)', [tx.user_id, 'Your top-up was approved.']);
    await runAsync('DELETE FROM notifications WHERE user_id = ? AND id NOT IN (SELECT id FROM notifications WHERE user_id = ? ORDER BY created_at DESC, id DESC LIMIT 3)', [tx.user_id, tx.user_id]);
    req.flash('success', 'Top-up approved');
    return res.redirect('/admin/transactions');
  }
  req.flash('success', 'Status updated');
  res.redirect('/admin/transactions');
});

// Top-Up Requests page: today's pending only by default
router.get('/topups', ensureAdmin, async (req, res) => {
  const all = req.query.all === '1';
  const q = (req.query.q || '').trim();
  const status = (req.query.status || 'pending');
  let sql = 'SELECT t.*, u.email, u.name, u.balance FROM transactions t JOIN users u ON u.id = t.user_id WHERE 1=1';
  const args = [];
  if (status) { sql += ' AND t.status = ?'; args.push(status); }
  if (!all) {
    sql += ' AND DATE(t.timestamp) = DATE(\'now\', \'localtime\')';
  }
  if (q) {
    sql += ' AND (u.email LIKE ? OR t.payment_method LIKE ? OR IFNULL(t.game_uid,\'\') LIKE ?)';
    args.push(`%${q}%`, `%${q}%`, `%${q}%`);
  }
  sql += ' ORDER BY t.timestamp DESC';
  const list = await allAsync(sql, args);
  // Mark fetched pending topups as seen for unread badge logic
  try {
    if (status === 'pending' && Array.isArray(list) && list.length) {
      for (const row of list) {
        await runAsync('INSERT OR IGNORE INTO admin_seen(type, item_id) VALUES (\'topup\', ?)', [row.id]);
      }
    }
  } catch (_) {}
  res.render('admin/topups', { title: 'Top-Up Requests', list, q, status, all });
});

// Wallet Deposits moderation
router.get('/deposits', ensureAdmin, async (req, res) => {
  const q = (req.query.q || '').trim();
  const all = req.query.all === '1';
  let sql = 'SELECT w.*, u.email, u.name FROM wallet_transactions w JOIN users u ON u.id = w.user_id WHERE w.type = "deposit"';
  const args = [];
  if (!all) {
    sql += ' AND DATE(w.timestamp) = DATE(\'now\', \'localtime\') AND w.status = "pending"';
  }
  if (q) {
    sql += ' AND (u.email LIKE ? OR w.method LIKE ? OR IFNULL(w.txn_id,\'\') LIKE ?)';
    args.push(`%${q}%`, `%${q}%`, `%${q}%`);
  }
  sql += ' ORDER BY w.timestamp DESC';
  const deposits = await allAsync(sql, args);
  const pay = await getAsync('SELECT * FROM payment_settings WHERE id = 1');
  // Mark fetched pending deposits as seen for unread badge logic
  try {
    if (Array.isArray(deposits) && deposits.length) {
      const pendings = deposits.filter(d => d.status === 'pending');
      for (const row of pendings) {
        await runAsync('INSERT OR IGNORE INTO admin_seen(type, item_id) VALUES (\'deposit\', ?)', [row.id]);
      }
    }
  } catch (_) {}
  res.render('admin/deposits', { title: 'Wallet Deposits', deposits, q, pay });
});

router.post('/deposits/:id/approve', ensureAdmin, async (req, res) => {
  const { id } = req.params;
  const dep = await getAsync('SELECT * FROM wallet_transactions WHERE id = ?', [id]);
  if (!dep) { req.flash('error', 'Deposit not found'); return res.redirect('/admin/deposits'); }
  if (dep.status !== 'approved') {
    await runAsync('UPDATE wallet_transactions SET status = "approved" WHERE id = ?', [id]);
    await runAsync('UPDATE users SET balance = ROUND(balance + ?, 2) WHERE id = ?', [dep.amount, dep.user_id]);
    await runAsync('INSERT INTO notifications (user_id, message) VALUES (?, ?)', [dep.user_id, 'Your deposit was approved. Balance credited.']);
    await runAsync('DELETE FROM notifications WHERE user_id = ? AND id NOT IN (SELECT id FROM notifications WHERE user_id = ? ORDER BY created_at DESC, id DESC LIMIT 3)', [dep.user_id, dep.user_id]);
  }
  req.flash('success', 'Deposit approved and balance credited');
  res.redirect('/admin/deposits');
});

router.post('/deposits/:id/reject', ensureAdmin, async (req, res) => {
  const { id } = req.params;
  const dep = await getAsync('SELECT * FROM wallet_transactions WHERE id = ?', [id]);
  if (!dep) { req.flash('error', 'Deposit not found'); return res.redirect('/admin/deposits'); }
  await runAsync('UPDATE wallet_transactions SET status = "rejected" WHERE id = ?', [id]);
  // Notify user
  await runAsync('INSERT INTO notifications (user_id, message) VALUES (?, ?)', [dep.user_id, 'Transaction ID incorrect. Please try again.']);
  req.flash('success', 'Deposit rejected');
  res.redirect('/admin/deposits');
});

module.exports = router;
