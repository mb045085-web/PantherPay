const express = require('express');
const { ensureAdmin } = require('../middleware/auth');
const { allAsync, getAsync, runAsync } = require('../db/db');

const router = express.Router();

// All routes here require admin
router.use(ensureAdmin);

// Health
router.get('/health', (req, res) => res.json({ ok: true }));

// Pending UNSEEN alerts for badges (Messenger-like). Uses admin_seen(type,item_id).
router.get('/alerts', async (req, res) => {
  const all = req.query.all === '1';
  const dateFilterDep = all ? '' : " AND DATE(w.timestamp)=DATE('now','localtime')";
  const dateFilterTop = all ? '' : " AND DATE(t.timestamp)=DATE('now','localtime')";

  const dep = await getAsync(
    `SELECT COUNT(1) AS c
     FROM wallet_transactions w
     WHERE w.type='deposit' AND w.status='pending'${dateFilterDep}
       AND NOT EXISTS (
         SELECT 1 FROM admin_seen s WHERE s.type='deposit' AND s.item_id = w.id
       )`
  );
  const top = await getAsync(
    `SELECT COUNT(1) AS c
     FROM transactions t
     WHERE t.status='pending'${dateFilterTop}
       AND NOT EXISTS (
         SELECT 1 FROM admin_seen s WHERE s.type='topup' AND s.item_id = t.id
       )`
  );
  res.json({ pendingDeposits: dep?.c || 0, pendingTopups: top?.c || 0 });
});

// Mark current pending items of a type as seen (used when admin opens the section)
router.post('/alerts/mark-seen', async (req, res) => {
  try {
    const type = (req.body?.type || '').toLowerCase();
    if (!['deposit','topup'].includes(type)) return res.status(400).json({ ok:false, error:'invalid type' });
    if (type === 'deposit') {
      await runAsync("INSERT OR IGNORE INTO admin_seen(type, item_id) SELECT 'deposit', id FROM wallet_transactions WHERE type='deposit' AND status='pending'");
    } else if (type === 'topup') {
      await runAsync("INSERT OR IGNORE INTO admin_seen(type, item_id) SELECT 'topup', id FROM transactions WHERE status='pending'");
    }
    // respond with latest counts (all-time unseen)
    const dep = await getAsync("SELECT COUNT(1) as c FROM wallet_transactions w WHERE w.type='deposit' AND w.status='pending' AND NOT EXISTS (SELECT 1 FROM admin_seen s WHERE s.type='deposit' AND s.item_id=w.id)");
    const top = await getAsync("SELECT COUNT(1) as c FROM transactions t WHERE t.status='pending' AND NOT EXISTS (SELECT 1 FROM admin_seen s WHERE s.type='topup' AND s.item_id=t.id)");
    res.json({ ok:true, pendingDeposits: dep?.c || 0, pendingTopups: top?.c || 0 });
  } catch (e) {
    res.status(500).json({ ok:false, error: e.message });
  }
});

// Products (diamond packs / weekly / monthly)
router.get('/products', async (req, res) => {
  const rows = await allAsync('SELECT * FROM products ORDER BY kind, price');
  res.json(rows);
});

router.post('/products', async (req, res) => {
  const { diamond_qty, price, enabled = 1, kind = 'pack' } = req.body;
  await runAsync('INSERT INTO products (diamond_qty, price, enabled, kind) VALUES (?, ?, ?, ?)', [diamond_qty, price, enabled ? 1 : 0, kind]);
  res.json({ ok: true });
});

router.put('/products/:id', async (req, res) => {
  const { diamond_qty, price, enabled, kind } = req.body;
  await runAsync('UPDATE products SET diamond_qty=COALESCE(?, diamond_qty), price=COALESCE(?, price), enabled=COALESCE(?, enabled), kind=COALESCE(?, kind) WHERE id=?', [diamond_qty, price, typeof enabled === 'undefined' ? null : (enabled ? 1 : 0), kind, req.params.id]);
  res.json({ ok: true });
});

router.delete('/products/:id', async (req, res) => {
  await runAsync('DELETE FROM products WHERE id=?', [req.params.id]);
  res.json({ ok: true });
});

// Notices
router.get('/notices', async (req, res) => {
  const rows = await allAsync('SELECT * FROM notices ORDER BY created_at DESC');
  res.json(rows);
});

router.post('/notices', async (req, res) => {
  const { title, content, level = 'info', active = 1 } = req.body;
  await runAsync('INSERT INTO notices (title, content, level, active) VALUES (?, ?, ?, ?)', [title, content, level, active ? 1 : 0]);
  res.json({ ok: true });
});

router.put('/notices/:id', async (req, res) => {
  const { title, content, level, active } = req.body;
  await runAsync('UPDATE notices SET title=COALESCE(?, title), content=COALESCE(?, content), level=COALESCE(?, level), active=COALESCE(?, active) WHERE id=?', [title, content, level, typeof active === 'undefined' ? null : (active ? 1 : 0), req.params.id]);
  res.json({ ok: true });
});

router.delete('/notices/:id', async (req, res) => {
  await runAsync('DELETE FROM notices WHERE id=?', [req.params.id]);
  res.json({ ok: true });
});

// Banners
router.get('/banners', async (req, res) => {
  const rows = await allAsync('SELECT * FROM banners ORDER BY sort_order ASC, id DESC');
  res.json(rows);
});

router.post('/banners', async (req, res) => {
  const { image_url, link_url = null, active = 1, sort_order = 0 } = req.body;
  await runAsync('INSERT INTO banners (image_url, link_url, active, sort_order) VALUES (?, ?, ?, ?)', [image_url, link_url, active ? 1 : 0, sort_order]);
  res.json({ ok: true });
});

router.put('/banners/:id', async (req, res) => {
  const { image_url, link_url, active, sort_order } = req.body;
  await runAsync('UPDATE banners SET image_url=COALESCE(?, image_url), link_url=COALESCE(?, link_url), active=COALESCE(?, active), sort_order=COALESCE(?, sort_order) WHERE id=?', [image_url, link_url, typeof active === 'undefined' ? null : (active ? 1 : 0), sort_order, req.params.id]);
  res.json({ ok: true });
});

router.delete('/banners/:id', async (req, res) => {
  await runAsync('DELETE FROM banners WHERE id=?', [req.params.id]);
  res.json({ ok: true });
});

// Offers
router.get('/offers', async (req, res) => {
  const rows = await allAsync('SELECT * FROM offers ORDER BY created_at DESC');
  res.json(rows);
});

router.post('/offers', async (req, res) => {
  const { title, image_url, price, active = 1, kind = 'deal' } = req.body;
  await runAsync('INSERT INTO offers (title, image_url, price, active, kind) VALUES (?, ?, ?, ?, ?)', [title, image_url, price, active ? 1 : 0, kind]);
  res.json({ ok: true });
});

router.put('/offers/:id', async (req, res) => {
  const { title, image_url, price, active, kind } = req.body;
  await runAsync('UPDATE offers SET title=COALESCE(?, title), image_url=COALESCE(?, image_url), price=COALESCE(?, price), active=COALESCE(?, active), kind=COALESCE(?, kind) WHERE id=?', [title, image_url, price, typeof active === 'undefined' ? null : (active ? 1 : 0), kind, req.params.id]);
  res.json({ ok: true });
});

router.delete('/offers/:id', async (req, res) => {
  await runAsync('DELETE FROM offers WHERE id=?', [req.params.id]);
  res.json({ ok: true });
});

// Payment Settings (single row)
router.get('/payment-settings', async (req, res) => {
  const row = await getAsync('SELECT * FROM payment_settings WHERE id = 1');
  res.json(row || {});
});

router.put('/payment-settings', async (req, res) => {
  const { wallet_enabled, bkash_enabled, nagad_enabled, rocket_enabled, bkash_key, nagad_key, rocket_key } = req.body;
  await runAsync('UPDATE payment_settings SET wallet_enabled=COALESCE(?, wallet_enabled), bkash_enabled=COALESCE(?, bkash_enabled), nagad_enabled=COALESCE(?, nagad_enabled), rocket_enabled=COALESCE(?, rocket_enabled), bkash_key=COALESCE(?, bkash_key), nagad_key=COALESCE(?, nagad_key), rocket_key=COALESCE(?, rocket_key) WHERE id = 1', [
    typeof wallet_enabled === 'undefined' ? null : (wallet_enabled ? 1 : 0),
    typeof bkash_enabled === 'undefined' ? null : (bkash_enabled ? 1 : 0),
    typeof nagad_enabled === 'undefined' ? null : (nagad_enabled ? 1 : 0),
    typeof rocket_enabled === 'undefined' ? null : (rocket_enabled ? 1 : 0),
    bkash_key, nagad_key, rocket_key
  ]);
  res.json({ ok: true });
});

// Promo codes
router.get('/promo-codes', async (req, res) => {
  const rows = await allAsync('SELECT * FROM promo_codes ORDER BY id DESC');
  res.json(rows);
});

router.post('/promo-codes', async (req, res) => {
  const { code, discount_percent = 0, max_uses = 0, expires_at = null, active = 1 } = req.body;
  await runAsync('INSERT INTO promo_codes (code, discount_percent, max_uses, expires_at, active) VALUES (?, ?, ?, ?, ?)', [code, discount_percent, max_uses, expires_at, active ? 1 : 0]);
  res.json({ ok: true });
});

router.put('/promo-codes/:id', async (req, res) => {
  const { code, discount_percent, max_uses, used_count, expires_at, active } = req.body;
  await runAsync('UPDATE promo_codes SET code=COALESCE(?, code), discount_percent=COALESCE(?, discount_percent), max_uses=COALESCE(?, max_uses), used_count=COALESCE(?, used_count), expires_at=COALESCE(?, expires_at), active=COALESCE(?, active) WHERE id=?', [code, discount_percent, max_uses, used_count, expires_at, typeof active === 'undefined' ? null : (active ? 1 : 0), req.params.id]);
  res.json({ ok: true });
});

router.delete('/promo-codes/:id', async (req, res) => {
  await runAsync('DELETE FROM promo_codes WHERE id=?', [req.params.id]);
  res.json({ ok: true });
});

// Users
router.get('/users', async (req, res) => {
  const q = (req.query.q || '').trim();
  const rows = q
    ? await allAsync('SELECT * FROM users WHERE email LIKE ? OR name LIKE ? ORDER BY id DESC', [`%${q}%`, `%${q}%`])
    : await allAsync('SELECT * FROM users ORDER BY id DESC');
  res.json(rows);
});

router.post('/users/:id/balance', async (req, res) => {
  const amount = parseFloat(req.body.amount || 0);
  await runAsync('UPDATE users SET balance = balance + ? WHERE id = ?', [amount, req.params.id]);
  res.json({ ok: true });
});

router.post('/users/:id/status', async (req, res) => {
  const role = req.body.role === 'admin' ? 'admin' : 'user';
  await runAsync('UPDATE users SET role=? WHERE id=?', [role, req.params.id]);
  res.json({ ok: true });
});

// Transactions
router.get('/transactions', async (req, res) => {
  const { status, user, method, from, to } = req.query;
  let sql = 'SELECT t.*, u.email FROM transactions t JOIN users u ON u.id = t.user_id WHERE 1=1';
  const args = [];
  if (status) { sql += ' AND t.status = ?'; args.push(status); }
  if (user) { sql += ' AND u.email LIKE ?'; args.push(`%${user}%`); }
  if (method) { sql += ' AND t.payment_method = ?'; args.push(method); }
  if (from) { sql += ' AND DATE(t.timestamp) >= DATE(?)'; args.push(from); }
  if (to) { sql += ' AND DATE(t.timestamp) <= DATE(?)'; args.push(to); }
  sql += ' ORDER BY t.timestamp DESC';
  const rows = await allAsync(sql, args);
  res.json(rows);
});

// CSV export
router.get('/transactions.csv', async (req, res) => {
  // reuse same filter logic
  req.query = req.query || {};
  let sql = 'SELECT t.id, u.email, t.diamond_qty, t.price, t.status, t.payment_method, t.timestamp FROM transactions t JOIN users u ON u.id = t.user_id WHERE 1=1';
  const args = [];
  const { status, user, method, from, to } = req.query;
  if (status) { sql += ' AND t.status = ?'; args.push(status); }
  if (user) { sql += ' AND u.email LIKE ?'; args.push(`%${user}%`); }
  if (method) { sql += ' AND t.payment_method = ?'; args.push(method); }
  if (from) { sql += ' AND DATE(t.timestamp) >= DATE(?)'; args.push(from); }
  if (to) { sql += ' AND DATE(t.timestamp) <= DATE(?)'; args.push(to); }
  sql += ' ORDER BY t.timestamp DESC';
  const rows = await allAsync(sql, args);
  const headers = ['ID','Email','Diamonds','Price','Status','Method','Timestamp'];
  const csv = [headers.join(',')].concat(rows.map(r => [r.id, r.email, r.diamond_qty, r.price, r.status, r.payment_method, r.timestamp].map(v => `"${String(v).replace(/"/g,'""')}"`).join(','))).join('\n');
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="transactions.csv"');
  res.send(csv);
});

// Wallet deposits: list and approve/reject
router.get('/wallet-deposits', async (req, res) => {
  const rows = await allAsync('SELECT w.*, u.email FROM wallet_transactions w JOIN users u ON u.id = w.user_id WHERE w.type = "deposit" ORDER BY w.timestamp DESC');
  res.json(rows);
});

router.post('/wallet-deposits/:id/approve', async (req, res) => {
  const dep = await getAsync('SELECT * FROM wallet_transactions WHERE id = ?', [req.params.id]);
  if (!dep) return res.status(404).json({ ok: false, error: 'Not found' });
  if (dep.status === 'approved') return res.json({ ok: true, already: true });
  await runAsync('UPDATE wallet_transactions SET status = "approved" WHERE id = ?', [dep.id]);
  await runAsync('UPDATE users SET balance = balance + ? WHERE id = ?', [dep.amount, dep.user_id]);
  res.json({ ok: true });
});

router.post('/wallet-deposits/:id/reject', async (req, res) => {
  const dep = await getAsync('SELECT * FROM wallet_transactions WHERE id = ?', [req.params.id]);
  if (!dep) return res.status(404).json({ ok: false, error: 'Not found' });
  await runAsync('UPDATE wallet_transactions SET status = "rejected" WHERE id = ?', [dep.id]);
  res.json({ ok: true });
});

module.exports = router;
