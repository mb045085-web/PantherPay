const express = require('express');
const { ensureAuth } = require('../middleware/auth');
const { allAsync, getAsync, runAsync, getSettings } = require('../db/db');
const { body, validationResult } = require('express-validator');
const bcrypt = require('bcrypt');

const router = express.Router();

// Keep req.user balance fresh for all authenticated user routes
router.use(ensureAuth, async (req, res, next) => {
  try {
    if (req.user && req.user.id) {
      const row = await getAsync('SELECT balance FROM users WHERE id = ?', [req.user.id]);
      const freshBalance = Number(row?.balance || 0);
      req.user.balance = freshBalance;
      res.locals.user = req.user;
    }
  } catch (e) {
    // Do not block request if refresh fails
  }
  next();
});

// Home dashboard: balance, notices, banners, offers, packs
router.get('/dashboard', ensureAuth, async (req, res) => {
  const user = req.user;
  const products = await allAsync('SELECT * FROM products WHERE enabled = 1 ORDER BY kind, price ASC');
  const history = await allAsync('SELECT * FROM transactions WHERE user_id = ? ORDER BY timestamp DESC LIMIT 10', [user.id]);
  const notices = await allAsync('SELECT * FROM notices WHERE active = 1 ORDER BY created_at DESC LIMIT 5');
  const banners = await allAsync('SELECT * FROM banners WHERE active = 1 ORDER BY sort_order ASC, id DESC');
  const offers = await allAsync('SELECT * FROM offers WHERE active = 1 ORDER BY created_at DESC LIMIT 8');
  const notifications = await allAsync('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 3', [user.id]);
  const pendingRow = await getAsync("SELECT COALESCE(SUM(amount), 0) as pending FROM wallet_transactions WHERE user_id = ? AND type = 'deposit' AND status = 'pending' AND DATE(timestamp) = DATE('now','localtime')", [user.id]);
  const pendingToday = Number(pendingRow?.pending || 0);
  res.render('pages/dashboard', { title: 'Dashboard', products, history, notices, banners, offers, notifications, pendingToday });
});

router.get('/topup', ensureAuth, async (req, res) => {
  const products = await allAsync('SELECT * FROM products WHERE enabled = 1 ORDER BY kind, price ASC');
  const ps = await getAsync('SELECT * FROM payment_settings WHERE id = 1');
  res.render('pages/topup', { title: 'Topup', products, ps });
});

// Dedicated category pages
router.get('/topup/freefire', ensureAuth, async (req, res) => {
  // Show items that are not weekly/monthly/pass style
  const products = await allAsync("SELECT * FROM products WHERE enabled = 1 AND (kind IS NULL OR TRIM(kind) = '' OR LOWER(kind) NOT IN ('weekly','monthly','pass','levelup','weekly_lite','weekly lite')) ORDER BY price ASC");
  res.render('pages/topup_list', { title: 'Free Fire TopUp', heading: 'Free Fire TopUp', products });
});

router.get('/topup/levelup', ensureAuth, async (req, res) => {
  const products = await allAsync("SELECT * FROM products WHERE enabled = 1 AND LOWER(kind) IN ('levelup','pass') ORDER BY price ASC");
  res.render('pages/topup_list', { title: 'Level Up Pass', heading: 'Level Up Pass', products });
});

router.get('/topup/weekly-monthly', ensureAuth, async (req, res) => {
  const products = await allAsync("SELECT * FROM products WHERE enabled = 1 AND LOWER(kind) IN ('weekly','monthly') ORDER BY price ASC");
  res.render('pages/topup_list', { title: 'Weekly & Monthly', heading: 'Weekly & Monthly', products });
});

router.get('/topup/weekly-lite', ensureAuth, async (req, res) => {
  const products = await allAsync("SELECT * FROM products WHERE enabled = 1 AND (LOWER(kind) LIKE 'weekly%lite%' OR LOWER(kind) = 'weekly_lite' OR LOWER(kind) = 'weekly lite') ORDER BY price ASC");
  res.render('pages/topup_list', { title: 'Weekly Lite', heading: 'Weekly Lite', products });
});
router.post('/topup', ensureAuth,
  body('product_id').isInt().withMessage('Invalid product'),
  body('game_uid').notEmpty().withMessage('Game UID required'),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      req.flash('error', errors.array().map(e => e.msg).join(', '));
      return res.redirect('/user/topup');
    }
    const product = await getAsync('SELECT * FROM products WHERE id = ? AND enabled = 1', [req.body.product_id]);
    if (!product) {
      req.flash('error', 'Selected pack not found');
      return res.redirect('/user/topup');
    }
    // Store price in BDT by applying currency rate
    const settings = await getSettings();
    const rate = Number(settings.currency_rate || 1);
    const finalPrice = Number(product.price) * rate;
    let walletDeducted = 0;
    // Default to wallet method since UI no longer asks for payment method
    const paymentMethod = 'wallet';
    if (paymentMethod === 'wallet') {
      const balRow = await getAsync('SELECT balance FROM users WHERE id = ?', [req.user.id]);
      const balance = Number(balRow?.balance || 0);
      if (balance < finalPrice) {
        req.flash('error', 'Insufficient wallet balance');
        return res.redirect('/user/topup');
      }
      await runAsync('UPDATE users SET balance = ROUND(balance - ?, 2) WHERE id = ?', [finalPrice, req.user.id]);
      walletDeducted = finalPrice;
    }
    await runAsync('INSERT INTO transactions (user_id, diamond_qty, price, status, payment_method, game_uid, wallet_deducted) VALUES (?, ?, ?, ?, ?, ?, ?)', [
      req.user.id, product.diamond_qty, finalPrice, 'pending', paymentMethod, req.body.game_uid, walletDeducted
    ]);
    req.flash('success', 'Topup request submitted');
    res.redirect('/user/orders');
  }
);

// Wallet
router.get('/wallet', ensureAuth, async (req, res) => {
  const balance = (await getAsync('SELECT balance FROM users WHERE id=?', [req.user.id]))?.balance || 0;
  const history = await allAsync('SELECT * FROM wallet_transactions WHERE user_id=? ORDER BY timestamp DESC LIMIT 20', [req.user.id]);
  const ps = await getAsync('SELECT * FROM payment_settings WHERE id = 1');
  res.render('pages/wallet', { title: 'Wallet', balance, history, ps });
});

router.post('/wallet/deposit', ensureAuth,
  body('amount').isFloat({ min: 0.5 }).withMessage('Minimum deposit is 0.5'),
  body('method').isIn(['bkash','nagad']).withMessage('Select a method'),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      req.flash('error', errors.array().map(e => e.msg).join(', '));
      return res.redirect('/user/wallet');
    }
    const amount = parseFloat(req.body.amount);
    // Create a pending deposit and redirect to confirmation page for txn id submission
    await runAsync('INSERT INTO wallet_transactions (user_id, type, amount, method, status) VALUES (?, "deposit", ?, ?, "pending")', [req.user.id, amount, req.body.method]);
    const row = await getAsync('SELECT last_insert_rowid() as id');
    const depositId = row?.id;
    req.flash('info', 'Please complete the payment and submit your Transaction ID');
    return res.redirect(`/user/wallet/deposit/${depositId}`);
  }
);

// Deposit confirm page (shows numbers/instructions per method)
router.get('/wallet/deposit/:id', ensureAuth, async (req, res) => {
  const dep = await getAsync('SELECT * FROM wallet_transactions WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
  if (!dep) { req.flash('error', 'Deposit request not found'); return res.redirect('/user/wallet'); }
  const ps = await getAsync('SELECT * FROM payment_settings WHERE id = 1');
  res.render('pages/deposit_confirm', { title: 'Confirm Deposit', dep, ps });
});

// Save Transaction ID (keeps status pending for admin approval)
router.post('/wallet/deposit/:id/confirm', ensureAuth,
  body('txn_id').notEmpty().withMessage('Transaction ID is required'),
  async (req, res) => {
    const dep = await getAsync('SELECT * FROM wallet_transactions WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
    if (!dep) { req.flash('error', 'Deposit request not found'); return res.redirect('/user/wallet'); }
    await runAsync('UPDATE wallet_transactions SET txn_id = ?, status = "pending" WHERE id = ?', [req.body.txn_id.trim(), dep.id]);
    req.flash('success', 'Transaction ID submitted. Waiting for admin approval.');
    res.redirect('/user/wallet');
  }
);

// Orders
router.get('/orders', ensureAuth, async (req, res) => {
  const orders = await allAsync('SELECT * FROM transactions WHERE user_id = ? ORDER BY timestamp DESC', [req.user.id]);
  res.render('pages/orders', { title: 'My Orders', orders });
});

router.get('/codes', ensureAuth, async (req, res) => {
  const codes = await allAsync('SELECT * FROM promo_codes WHERE active = 1 ORDER BY id DESC');
  res.render('pages/codes', { title: 'My Codes', codes });
});

router.post('/codes/redeem', ensureAuth, body('code').notEmpty(), async (req, res) => {
  const code = (req.body.code || '').trim();
  const row = await getAsync('SELECT * FROM promo_codes WHERE code = ? AND active = 1', [code]);
  if (row.expires_at && new Date(row.expires_at) < new Date()) { req.flash('error', 'Code expired'); return res.redirect('/user/codes'); }
  if (row.max_uses > 0 && row.used_count >= row.max_uses) { req.flash('error', 'Code usage limit reached'); return res.redirect('/user/codes'); }
  // Simple redemption: add bonus to wallet based on discount_percent
  const bonus = Math.max(0, Number(row.discount_percent || 0));
  if (bonus > 0) {
    const amt = Number(bonus.toFixed(2));
    await runAsync('UPDATE users SET balance = ROUND(balance + ?, 2) WHERE id = ?', [amt, req.user.id]);
    await runAsync('INSERT INTO wallet_transactions (user_id, type, amount, method) VALUES (?, "deposit", ?, "wallet")', [req.user.id, amt]);
  }
  await runAsync('UPDATE promo_codes SET used_count = used_count + 1 WHERE id = ?', [row.id]);
  const settings = await getSettings();
  const symbol = settings.currency_symbol || '৳';
  req.flash('success', `Code applied. Bonus ${symbol}${bonus.toFixed(2)} added to wallet.`);
  res.redirect('/user/codes');
});

// Account
router.get('/account', ensureAuth, async (req, res) => {
  const sums = await getAsync('SELECT COALESCE(SUM(price),0) as total, COALESCE(MAX(price),0) as maxp FROM transactions WHERE user_id = ? AND (status = "approved" OR status = "completed")', [req.user.id]);
  const settingsAcc = await getSettings();
  const rate = Number(settingsAcc.currency_rate || 1);
  const totalTopup = Number(sums?.total || 0);
  const maxTopup = Number(sums?.maxp || 0);
  const totalTopupBDT = totalTopup * rate;
  const maxTopupBDT = maxTopup * rate;
  // Compute level based on total money ADDED by the user (approved/completed deposits)
  // Sum wallet deposits that are approved/completed
  const depRow = await getAsync("SELECT COALESCE(SUM(amount),0) as added FROM wallet_transactions WHERE user_id = ? AND type = 'deposit' AND status IN ('approved','completed')", [req.user.id]);
  const totalAdded = Number(depRow?.added || 0);
  const totalAddedBDT = totalAdded * rate;
  // Rule: every ৳1000 added = +1 level
  const level = Math.max(0, Math.floor(totalAddedBDT / 1000));
  res.render('pages/account', { title: 'My Account', stats: { totalTopup, maxTopup, totalTopupBDT, maxTopupBDT, level } });
});

router.post('/account/profile', ensureAuth,
  body('name').notEmpty(),
  body('phone').optional().isString(),
  async (req, res) => {
    await runAsync('UPDATE users SET name = ?, phone = ? WHERE id = ?', [req.body.name, req.body.phone || null, req.user.id]);
    req.flash('success', 'Profile updated');
    res.redirect('/user/account');
  }
);

router.post('/account/avatar', ensureAuth,
  body('avatar_url').optional().isURL().withMessage('Provide a valid image URL'),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      req.flash('error', errors.array().map(e => e.msg).join(', '));
      return res.redirect('/user/account');
    }
    await runAsync('UPDATE users SET avatar_url = ? WHERE id = ?', [req.body.avatar_url || null, req.user.id]);
    req.flash('success', 'Profile picture updated');
    res.redirect('/user/account');
  }
);

router.post('/account/password', ensureAuth,
  body('current').notEmpty(),
  body('password').isLength({ min: 6 }),
  body('confirm').custom((v, { req }) => v === req.body.password),
  async (req, res) => {
    const userRow = await getAsync('SELECT * FROM users WHERE id = ?', [req.user.id]);
    if (!userRow || !userRow.password_hash) { req.flash('error', 'Password change not available for this account'); return res.redirect('/user/account'); }
    const ok = await bcrypt.compare(req.body.current, userRow.password_hash);
    if (!ok) { req.flash('error', 'Current password incorrect'); return res.redirect('/user/account'); }
    const hash = await bcrypt.hash(req.body.password, 10);
    await runAsync('UPDATE users SET password_hash = ? WHERE id = ?', [hash, req.user.id]);
    req.flash('success', 'Password updated');
    res.redirect('/user/account');
  }
);

module.exports = router;
