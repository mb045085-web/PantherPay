const express = require('express');
const passport = require('passport');
const bcrypt = require('bcrypt');
const { body, validationResult } = require('express-validator');
const { getAsync, runAsync } = require('../db/db');

const router = express.Router();

router.get('/login', (req, res) => {
  res.render('pages/login', { title: 'Login', forceDark: true, hideThemeToggle: true });
});

router.post('/login',
  body('email').isEmail().withMessage('Valid email required'),
  body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      req.flash('error', errors.array().map(e => e.msg).join(', '));
      return res.redirect('/login');
    }
    next();
  },
  (req, res, next) => {
    passport.authenticate('local', async (err, user, info) => {
      if (err) return next(err);
      if (!user) {
        req.flash('error', info && info.message ? info.message : 'Login failed');
        return res.redirect('/login');
      }
      req.logIn(user, async (err2) => {
        if (err2) return next(err2);
        try {
          await runAsync('UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?', [user.id]);
        } catch (_) {}
        return res.redirect('/user/dashboard?li=1');
      });
    })(req, res, next);
  }
);

router.get('/register', (req, res) => {
  res.render('pages/register', { title: 'Register' });
});

router.post('/register',
  body('name').notEmpty().withMessage('Name required'),
  body('email').isEmail().withMessage('Valid email required'),
  body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
  body('confirm').custom((value, { req }) => value === req.body.password).withMessage('Passwords do not match'),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      req.flash('error', errors.array().map(e => e.msg).join(', '));
      return res.redirect('/register');
    }
    try {
      const existing = await getAsync('SELECT * FROM users WHERE email = ?', [req.body.email]);
      if (existing) {
        req.flash('error', 'Email already registered');
        return res.redirect('/register');
      }
      const hash = await bcrypt.hash(req.body.password, 10);
      await runAsync('INSERT INTO users (name, email, password_hash, role, balance) VALUES (?, ?, ?, ?, ?)', [
        req.body.name, req.body.email, hash, 'user', 0
      ]);
      req.flash('success', 'Registration successful. Please log in.');
      res.redirect('/login');
    } catch (e) {
      req.flash('error', e.message);
      res.redirect('/register');
    }
  }
);

router.get('/logout', (req, res, next) => {
  req.logout(err => {
    if (err) return next(err);
    res.redirect('/login');
  });
});

// Google OAuth
router.get('/auth/google', passport.authenticate('google', { scope: ['profile', 'email'] }));
router.get('/auth/google/callback',
  passport.authenticate('google', { failureRedirect: '/login', failureFlash: true }),
  (req, res) => res.redirect('/user/dashboard?li=1')
);

module.exports = router;
