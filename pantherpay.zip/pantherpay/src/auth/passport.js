const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const bcrypt = require('bcrypt');
const { getAsync, allAsync } = require('../db/db');

passport.use(new LocalStrategy({ usernameField: 'email' }, async (email, password, done) => {
  try {
    const user = await getAsync('SELECT * FROM users WHERE email = ?', [email]);
    if (!user || !user.password_hash) return done(null, false, { message: 'Invalid credentials' });
    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) return done(null, false, { message: 'Invalid credentials' });
    return done(null, user);
  } catch (e) {
    return done(e);
  }
}));

passport.use(new GoogleStrategy({
  clientID: process.env.GOOGLE_CLIENT_ID || ' ',
  clientSecret: process.env.GOOGLE_CLIENT_SECRET || ' ',
  callbackURL: process.env.GOOGLE_CALLBACK_URL || 'http://localhost:3000/auth/google/callback'
}, async (accessToken, refreshToken, profile, done) => {
  try {
    let user = await getAsync('SELECT * FROM users WHERE google_id = ?', [profile.id]);
    if (!user) {
      const email = (profile.emails && profile.emails[0] && profile.emails[0].value) || `${profile.id}@google.local`;
      await require('../db/db').runAsync('INSERT INTO users (name, email, google_id, role, balance) VALUES (?, ?, ?, ?, ?)', [
        profile.displayName || 'Google User', email, profile.id, 'user', 0
      ]);
      user = await getAsync('SELECT * FROM users WHERE google_id = ?', [profile.id]);
    }
    return done(null, user);
  } catch (e) {
    return done(e);
  }
}));

passport.serializeUser((user, done) => {
  done(null, user.id);
});

passport.deserializeUser(async (id, done) => {
  try {
    const user = await getAsync('SELECT * FROM users WHERE id = ?', [id]);
    done(null, user);
  } catch (e) {
    done(e);
  }
});
